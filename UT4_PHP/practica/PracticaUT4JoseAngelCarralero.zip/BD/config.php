<?php
    define("DB_HOST", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");
    define("DB_NOMBRE", "academia");
    define("DB_CHARSET", "utf8");
?>